<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Orders extends CI_Controller {
    public $tablename='orders';
    public $tablename2='order_product_map';

	public function __construct()
	{
        parent::__construct();
		$this->load->model('crud_model','crud');

		if (!$this->session->userdata('isUserLoggedIn')){
			redirect(site_url('login'));
		}else if($this->session->userdata('isUserLoggedIn') && $this->session->userdata('level') !='1'){
			redirect(site_url());
		}
	}
	
	public function index(){
		
	}

	public function getAllRecords(){
		$conf = array(
            'table' => $this->tablename,
            'join' => array(
                'table' => 'user',
                'condition' => 'user.user_id = orders.user_id'
            ),
            'orderBy' => 'order_date',
            'orderType' => 'desc'
		);
		$result['records']  = $this->crud->getRows($conf);
		echo json_encode($result);
	}
	
	public function deleteRecord(){
		if (!empty($_POST)){
			$id= array(
				'order_id' => $this->input->post('order_id')
			);
			if($this->crud->db_delete($this->tablename2,$id)){
                //remove order entry
                $this->crud->db_delete($this->tablename,$id);

				$result['error'] = false;
				$result['msg'] ='Record deleted successfully.';
			}else{
				$result['error'] = true;
				$result['form'] ='Something went wrong. Please try again.';
			}
			echo json_encode($result);
		}
	}

	public function searchRecord(){
		if (!empty($_POST)){
			$value = $this->input->post('text');
			$fields= array('order_id', 'status', 'total');
			$query =  $this->crud->db_search($this->tablename,$fields, $value);
			if($query){
				$result['records']= $query;
			}
			echo json_encode($result);
		}
	}
}
