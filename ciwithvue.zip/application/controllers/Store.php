<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Store extends CI_Controller {
	public function __construct()
	{
        parent::__construct();
		$this->load->model('crud_model','crud');
	}

	public function index()
	{
		$data = array(
			'title' => 'Store'
		);

		$conf=array(
			'table' => 'category',
			'limit' => 3,
			'orderBy' => 'category_id',
			'orderType' => 'asc'
		);

		$data['categories']=$this->crud->getRows($conf);
		
		foreach($data['categories'] as $k=>$category){
			$conf1=array(
				'table' => 'product',
				'limit' => 3,
				'orderBy' => 'product_id',
				'orderType' => 'desc',
				'conditions' => array(
					'category' => $category['category_id']
				)
			);
	
			$data['categories'][$k]['products']=$this->crud->getRows($conf1);
		}
		
		$this->template->load('frontpage', 'contents' , 'store', $data);
	}

	public function getProductByCategories(){
		
		$conf=array(
			'table' => 'category',
			'limit' => 3,
			'orderBy' => 'category_id',
			'orderType' => 'asc'
		);

		$result['categories']=$this->crud->getRows($conf);
		if(!empty($result['categories']) && count($result['categories']) >0){
			foreach($result['categories'] as $k=>$category){
				$conf1=array(
					'table' => 'product',
					'orderBy' => 'product_id',
					'orderType' => 'desc',
					'conditions' => array(
						'category' => $category['category_id']
					)
				);
		
				$result['categories'][$k]['products']=$this->crud->getRows($conf1);
			}

			echo json_encode($result);
		}
	}
	public function generateOrder(){
		
		if(!empty($_POST)){
			$product_ids=explode(',',$this->input->post('product_ids'));
			$product_qty=explode(',',$this->input->post('product_qty'));

			$data = array(
				'user_id'=> $this->session->userdata('userId'),
				'total'=> $this->input->post('cartTotal'),
				'order_date'=> date('Y-m-d H:i:s')
			);
			$order_id=$this->crud->db_insert('orders',$data);
			
			if($order_id > 0){
				foreach($product_ids as $k=>$pid){
					$pdata = array(
						'order_id'=> $order_id,
						'product_id'=> $pid,
						'quantity'=> $product_qty[$k]
					);
					$order_id=$this->crud->db_insert('order_product_map',$pdata);
				}

				$result['error'] = false;
				$result['msg'] ='Order created successfully.';
			}else{
				$result['error'] = true;
				$result['msg'] ='Something went wrong. Please try again.';
			}
			echo json_encode($result);
		}
	}
}