<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	public function __construct()
	{
        parent::__construct();
        
		$this->load->model('crud_model','crud');
		
		
	}
	public function index()
	{
		if ($this->session->userdata('isUserLoggedIn') && $this->session->userdata('level')=='1') {
			redirect(site_url('admin/dashboard'));
		}else if($this->session->userdata('isUserLoggedIn')){
			redirect(site_url());
		}

		$this->load->view('login.php');
    }
    public function submitForm(){
        $config = array(
            array(
                'field' => 'email',
                'label' => 'Email',
                'rules' => 'trim|required|valid_email'
            ),
            array(
                'field' => 'pass',
                'label' => 'Password',
                'rules' => 'trim|required'
            )
        );
        $this->form_validation->set_rules($config);

        if ($this->form_validation->run() == FALSE) {
            $result['error'] = true;
            $result['msg'] = array(
                'email'=>form_error('email'),
                'pass'=>form_error('pass')
            );  
        }else{
            $conf = array(
				'table' => 'user',
				'returnType' => 'single',
				'conditions' => array(
					'email'=> $this->input->post('email'),
					'pass' => md5($this->input->post('pass'))
				)
			);

			$checkLogin = $this->crud->getRows($conf);
			if($checkLogin){
				
				$this->session->set_userdata('isUserLoggedIn', TRUE);
				$this->session->set_userdata('userId', $checkLogin['user_id']);
				$this->session->set_userdata('fullname', $checkLogin['fullname']);
				$this->session->set_userdata('level', $checkLogin['level']);
				
				if($checkLogin['level']==1){
					$result['path']=site_url('admin/dashboard');
				}else{
					$result['path']=site_url();
				}
				
				$result['error'] = false;
                $result['msg'] ='Login done successfully.';
			}else{
				$result['error'] = true;
				$result['form'] = 'Wrong email or password, please try again.';
			}
                
        }
        echo json_encode($result);
	}
	
	public function logout(){
		
		$this->session->unset_userdata('isUserLoggedIn');
		$this->session->unset_userdata('userId');
		$this->session->unset_userdata('fullname');
		$this->session->unset_userdata('level');
        $this->session->sess_destroy();
        redirect(site_url());
    }
}
