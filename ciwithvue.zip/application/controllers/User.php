<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {
	public $tablename='user';

	public function __construct()
	{
        parent::__construct();
		$this->load->model('crud_model','crud');

		if (!$this->session->userdata('isUserLoggedIn')){
			redirect(site_url('login'));
		}else if($this->session->userdata('isUserLoggedIn') && $this->session->userdata('level') !='1'){
			redirect(site_url());
		}
	}
	
	public function index(){
		
	}

	public function getAllRecords(){
		$conf = array(
			'table' => $this->tablename
		);
		$result['records']  = $this->crud->getRows($conf);
		echo json_encode($result);
	}

	public function addRecord(){
		if (!empty($_POST)){
			$config = array(
				array(
					'field' => 'fullname',
					'label' => 'Fullname',
					'rules' => 'trim|required'
				),
				array(
					'field' => 'address',
					'label' => 'Address',
					'rules' => 'trim|required'
				),
				array(
					'field' => 'email',
					'label' => 'Email',
					'rules' => 'trim|required|valid_email|is_unique[user.email]'
				),
				array(
					'field' => 'mobile',
					'label' => 'Mobile',
					'rules' => 'trim|required'
				),
				array(
					'field' => 'pass',
					'label' => 'Password',
					'rules' => 'trim|required'
				)
			);
			
			$this->form_validation->set_rules($config);

			if ($this->form_validation->run() == FALSE) {
				$result['error'] = true;
				$result['msg'] = array(
					'fullname'=>form_error('fullname'),
					'address'=>form_error('address'),
					'email'=>form_error('email'),
					'mobile'=>form_error('mobile'),
					'pass'=>form_error('pass')
				);  
			}else{
				$data = array(
					'fullname'=> $this->input->post('fullname'),
					'address'=> $this->input->post('address'),
					'email'=> $this->input->post('email'),
					'mobile'=> $this->input->post('mobile'),
					'pass'=> md5($this->input->post('pass'))
				);
				
				if($this->crud->db_insert($this->tablename,$data)){
					$result['error'] = false;
					$result['msg'] ='Record added successfully.';
				}else{
					$result['error'] = true;
					$result['form'] ='Something went wrong. Please try again.';
				}
					
			}
			echo json_encode($result);
		}
	}

	public function updateRecord(){
		if (!empty($_POST)){
			$config = array(
				array(
					'field' => 'fullname',
					'label' => 'Fullname',
					'rules' => 'trim|required'
				),
				array(
					'field' => 'address',
					'label' => 'Address',
					'rules' => 'trim|required'
				),
				array(
					'field' => 'email',
					'label' => 'Email',
					'rules' => 'trim|required|valid_email'
				),
				array(
					'field' => 'mobile',
					'label' => 'Mobile',
					'rules' => 'trim|required'
				),
				array(
					'field' => 'pass',
					'label' => 'Password',
					'rules' => 'trim|required'
				)
			);
			
			$this->form_validation->set_rules($config);

			if ($this->form_validation->run() == FALSE) {
				$result['error'] = true;
				$result['msg'] = array(
					'fullname'=>form_error('fullname'),
					'address'=>form_error('address'),
					'email'=>form_error('email'),
					'mobile'=>form_error('mobile'),
					'pass'=>form_error('pass')
				);  
			}else{
				
				$data = array(
					'fullname'=> $this->input->post('fullname'),
					'address'=> $this->input->post('address'),
					'email'=> $this->input->post('email'),
					'mobile'=> $this->input->post('mobile'),
					'pass'=> md5($this->input->post('pass'))
				);
				$id= array(
					'user_id' => $this->input->post('user_id')
				);
				
				if($this->crud->db_update($this->tablename,$data, $id)){
					$result['error'] = false;
					$result['msg'] ='Record updated successfully.';
				}else{
					$result['error'] = true;
					$result['form'] ='Something went wrong. Please try again.';
				}
					
			}
			echo json_encode($result);
		}
	}
	
	public function deleteRecord(){
		if (!empty($_POST)){
			$id= array(
				'user_id' => $this->input->post('user_id')
			);
			if($this->crud->db_delete($this->tablename,$id)){
				$result['error'] = false;
				$result['msg'] ='Record deleted successfully.';
			}else{
				$result['error'] = true;
				$result['form'] ='Something went wrong. Please try again.';
			}
			echo json_encode($result);
		}
	}

	public function searchRecord(){
		if (!empty($_POST)){
			$value = $this->input->post('text');
			$fields= array('fullname');
			$query =  $this->crud->db_search($this->tablename,$fields, $value);
			if($query){
				$result['records']= $query;
			}
			echo json_encode($result);
		}
	}
}
