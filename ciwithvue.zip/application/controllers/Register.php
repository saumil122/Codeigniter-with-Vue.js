<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {
	public function __construct()
	{
        parent::__construct();
        
        $this->load->model('crud_model','crud');
        
        if ($this->session->userdata('isUserLoggedIn') && $this->session->userdata('level')=='1') {
			redirect(site_url('admin/dashboard'));
		}else if($this->session->userdata('isUserLoggedIn')){
			redirect(site_url());
		}
	}
	public function index()
	{
		$this->load->view('register.php');
    }
    public function submitForm(){
        $config = array(
            array(
                'field' => 'fullname',
                'label' => 'Fullname',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'address',
                'label' => 'Address',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'email',
                'label' => 'Email',
                'rules' => 'trim|required|valid_email|is_unique[user.email]'
            ),
            array(
                'field' => 'mobile',
                'label' => 'Mobile',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'pass',
                'label' => 'Password',
                'rules' => 'trim|required'
            )
        );
        $this->form_validation->set_rules($config);

        if ($this->form_validation->run() == FALSE) {
            $result['error'] = true;
            $result['msg'] = array(
                'fullname'=>form_error('fullname'),
                'address'=>form_error('address'),
                'email'=>form_error('email'),
                'mobile'=>form_error('mobile'),
                'pass'=>form_error('pass')
            );  
        }else{
            $data = array(
                'fullname'=> $this->input->post('fullname'),
                'address'=> $this->input->post('address'),
                'email'=> $this->input->post('email'),
                'mobile'=> $this->input->post('mobile'),
                'pass'=> md5($this->input->post('pass'))
            );
            
            if($this->crud->db_insert('user',$data)){
                $result['error'] = false;
                $result['msg'] ='Registration done successfully.';
            }
                
        }
        echo json_encode($result);
    }
}
