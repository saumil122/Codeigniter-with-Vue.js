<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Category extends CI_Controller {
	public $tablename='category';

	public function __construct()
	{
        parent::__construct();
		$this->load->model('crud_model','crud');

		if (!$this->session->userdata('isUserLoggedIn')){
			redirect(site_url('login'));
		}else if($this->session->userdata('isUserLoggedIn') && $this->session->userdata('level') !='1'){
			redirect(site_url());
		}
	}
	
	public function index(){
		
	}

	public function getAllRecords(){
		$conf = array(
			'table' => $this->tablename
		);
		$result['records']  = $this->crud->getRows($conf);
		echo json_encode($result);
	}

	public function addRecord(){
		if (!empty($_POST)){
			$config = array(
				array(
					'field' => 'category_name',
					'label' => 'Category name',
					'rules' => 'trim|required'
				)
			);
			
			$this->form_validation->set_rules($config);

			if ($this->form_validation->run() == FALSE) {
				$result['error'] = true;
				$result['msg'] = array(
					'category_name'=>form_error('category_name')
				);  
			}else{
				$data = array(
					'category_name'=> $this->input->post('category_name')
				);
				
				if($this->crud->db_insert($this->tablename,$data)){
					$result['error'] = false;
					$result['msg'] ='Record added successfully.';
				}else{
					$result['error'] = true;
					$result['form'] ='Something went wrong. Please try again.';
				}
					
			}
			echo json_encode($result);
		}
	}

	public function updateRecord(){
		if (!empty($_POST)){
			$config = array(
				array(
					'field' => 'category_name',
					'label' => 'Category name',
					'rules' => 'trim|required'
				)
			);
			
			$this->form_validation->set_rules($config);

			if ($this->form_validation->run() == FALSE) {
				$result['error'] = true;
				$result['msg'] = array(
					'category_name'=>form_error('category_name')
				);  
			}else{
				
				$data = array(
					'category_name'=> $this->input->post('category_name')
                );
                
				$id= array(
					'category_id' => $this->input->post('category_id')
				);
				
				if($this->crud->db_update($this->tablename,$data, $id)){
					$result['error'] = false;
					$result['msg'] ='Record updated successfully.';
				}else{
					$result['error'] = true;
					$result['form'] ='Something went wrong. Please try again.';
				}
					
			}
			echo json_encode($result);
		}
	}
	
	public function deleteRecord(){
		if (!empty($_POST)){
			$id= array(
				'category_id' => $this->input->post('category_id')
			);
			if($this->crud->db_delete($this->tablename,$id)){
				$result['error'] = false;
				$result['msg'] ='Record deleted successfully.';
			}else{
				$result['error'] = true;
				$result['form'] ='Something went wrong. Please try again.';
			}
			echo json_encode($result);
		}
	}

	public function searchRecord(){
		if (!empty($_POST)){
			$value = $this->input->post('text');
			$fields= array('category_name');
			$query =  $this->crud->db_search($this->tablename,$fields, $value);
			if($query){
				$result['records']= $query;
			}
			echo json_encode($result);
		}
	}
}
