<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {
	public $tablename='product';

	public function __construct()
	{
        parent::__construct();
		$this->load->model('crud_model','crud');

		if (!$this->session->userdata('isUserLoggedIn')){
			redirect(site_url('login'));
		}else if($this->session->userdata('isUserLoggedIn') && $this->session->userdata('level') !='1'){
			redirect(site_url());
		}
	}
	
	public function index(){
		
	}

	public function getAllRecords(){
		$conf = array(
            'table' => $this->tablename,
            'join' => array(
                'table' => 'category',
                'condition' => 'category.category_id = product.category'
            ),
            'orderBy' => 'product_id',
            'orderType' => 'asc'
		);
		$result['records']  = $this->crud->getRows($conf);
		echo json_encode($result);
	}

	public function addRecord(){
		if (!empty($_POST)){
			$config = array(
				array(
					'field' => 'name',
					'label' => 'product name',
					'rules' => 'trim|required'
                ),
                array(
					'field' => 'category',
					'label' => 'category',
					'rules' => 'trim|required'
                ),
                array(
					'field' => 'description',
					'label' => 'description',
					'rules' => 'trim|required'
				),
                /*array(
					'field' => 'image',
					'label' => 'image',
					'rules' => 'trim|required'
				),*/
                array(
					'field' => 'price',
					'label' => 'price',
					'rules' => 'trim|required|decimal'
				)
			);
			
			$this->form_validation->set_rules($config);

			if ($this->form_validation->run() == FALSE) {
				$result['error'] = true;
				$result['msg'] = array(
                    'name'=>form_error('name'),
                    'category'=>form_error('category'),
                    'description'=>form_error('description'),
                    /*'image'=>form_error('image'),*/
                    'price'=>form_error('price')
				);  
			}else{
				$data = array(
                    'name'=> $this->input->post('name'),
                    'category'=> $this->input->post('category'),
                    'description'=> $this->input->post('description'),
                    'image'=> $this->input->post('image'),
                    'price'=> $this->input->post('price')
				);
				
				if($this->crud->db_insert($this->tablename,$data)){
					$result['error'] = false;
					$result['msg'] ='Record added successfully.';
				}else{
					$result['error'] = true;
					$result['form'] ='Something went wrong. Please try again.';
				}
					
			}
			echo json_encode($result);
		}
	}

	public function updateRecord(){
		if (!empty($_POST)){
            
			$config = array(
				array(
					'field' => 'name',
					'label' => 'product name',
					'rules' => 'trim|required'
                ),
                array(
					'field' => 'category',
					'label' => 'category',
					'rules' => 'trim|required'
                ),
                array(
					'field' => 'description',
					'label' => 'description',
					'rules' => 'trim|required'
				),
                /*array(
					'field' => 'image',
					'label' => 'image',
					'rules' => 'trim|required'
				),*/
                array(
					'field' => 'price',
					'label' => 'price',
					'rules' => 'trim|required|decimal'
				)
			);
			
			$this->form_validation->set_rules($config);

			if ($this->form_validation->run() == FALSE) {
				$result['error'] = true;
				$result['msg'] = array(
                    'name'=>form_error('name'),
                    'category'=>form_error('category'),
                    'description'=>form_error('description'),
                    /*'image'=>form_error('image'),*/
                    'price'=>form_error('price')
				);   
			}else{
				
				$data = array(
                    'name'=> $this->input->post('name'),
                    'category'=> $this->input->post('category'),
                    'description'=> $this->input->post('description'),
                    'image'=> $this->input->post('image'),
                    'price'=> $this->input->post('price')
				);
                
				$id= array(
					'product_id' => $this->input->post('product_id')
				);
				
				if($this->crud->db_update($this->tablename,$data, $id)){
					$result['error'] = false;
					$result['msg'] ='Record updated successfully.';
				}else{
					$result['error'] = true;
					$result['form'] ='Something went wrong. Please try again.';
				}
					
			}
			echo json_encode($result);
		}
	}
	
	public function deleteRecord(){
		if (!empty($_POST)){
			$id= array(
				'product_id' => $this->input->post('product_id')
			);
			if($this->crud->db_delete($this->tablename,$id)){
				$result['error'] = false;
				$result['msg'] ='Record deleted successfully.';
			}else{
				$result['error'] = true;
				$result['form'] ='Something went wrong. Please try again.';
			}
			echo json_encode($result);
		}
	}

	public function searchRecord(){
		if (!empty($_POST)){
			$value = $this->input->post('text');
			$fields= array('name');
			$query =  $this->crud->db_search($this->tablename,$fields, $value);
			if($query){
				$result['records']= $query;
			}
			echo json_encode($result);
		}
    }
    
    public function upload(){
        /* Getting file name */
        $filename = $_FILES['file']['name'];

        $config = array(
            'upload_path' => FCPATH."uploads/",
            'allowed_types' => "gif|jpg|png|jpeg|pdf",
            'overwrite' => TRUE,
            'max_size' => "2048000", // Can be set to particular file size , here it is 2 MB(2048 Kb)
            'max_height' => "768",
            'max_width' => "1024"
        );
        $this->load->library('upload', $config);

        if($this->upload->do_upload('file')){
            $data = array('upload_data' => $this->upload->data());
            
            $result['error'] = false;
			$result['msg'] =site_url('uploads/'.$filename);
        }else{
            $error = array('error' => $this->upload->display_errors());
        
            $result['error'] = true;
            $result['msg'] = 'Error occured while uploading image.';
        }
        echo json_encode($result);
    }
}
