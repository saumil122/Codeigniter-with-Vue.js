<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	public function __construct()
	{
        parent::__construct();
		$this->load->model('crud_model','crud');

		if (!$this->session->userdata('isUserLoggedIn')){
			redirect(site_url('login'));
		}else if($this->session->userdata('isUserLoggedIn') && $this->session->userdata('level') !='1'){
			redirect(site_url());
		}
	}
	public function index()
	{
		redirect(site_url('admin/dashboard'));
    }
    public function dashboard()
	{
        $data = array(
			'title' => 'Dashboard'
		);

		$this->template->load('admin/layout', 'contents' , 'admin/dashboard', $data);
	}
	
	public function category(){
		$data = array(
			'title' => 'Category'
		);

		$conf = array(
			'table' => 'category'
		);
		$data['records'] = $this->crud->getRows($conf);
		
		$this->template->load('admin/layout', 'contents' , 'admin/category', $data);
	}

	public function product(){
		$data = array(
			'title' => 'Product'
		);
		/* get all categories*/
		$conf = array(
			'table' => 'category'
		);
		$data['categories'] = $this->crud->getRows($conf);

		$conf = array(
			'table' => 'product'
		);
		$data['records'] = $this->crud->getRows($conf);
		
		$this->template->load('admin/layout', 'contents' , 'admin/product', $data);
	}

	public function orders()
	{
        $data = array(
			'title' => 'Orders'
		);

		$this->template->load('admin/layout', 'contents' , 'admin/orders', $data);
	}

	public function users()
	{
        $data = array(
			'title' => 'Users'
		);

		$this->template->load('admin/layout', 'contents' , 'admin/users', $data);
	}
}
