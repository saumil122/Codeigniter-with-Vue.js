<!DOCTYPE html>
<html lang=en>
<head>
    <meta charset=utf-8>
    <meta http-equiv=X-UA-Compatible content="IE=edge">
    <meta name=viewport content="width=device-width,initial-scale=1,shrink-to-fit=no">
    <meta name=description content="Start your development with a Design System for Bootstrap 4 and Vue.js">
    <meta name=author content="Saumil Nagariya">
    <title>Codeigniter with Vue.js</title>
    <link href="<?php echo site_url('/assets/css/bootstrap.css')?>" rel="stylesheet">
    <link href="<?php echo site_url('/assets/css/main.css')?>" rel="stylesheet">
    
    <script src="<?php echo site_url('/assets/js/jquery-3.4.1.js')?>"></script>
    <script src="<?php echo site_url('/assets/js/popper.js')?>"></script>
    <script src="<?php echo site_url('/assets/js/bootstrap.js')?>"></script>
    <script src="<?php echo site_url('/assets/js/vue.js')?>"></script>
    <script src="<?php echo site_url('/assets/js/vue-router.js')?>"></script>
    <script src="<?php echo site_url('/assets/js/axios.min.js')?>"></script>
<head>
<body>
<div id="app">
<transition enter-active-class="animated fadeInLeft" leave-active-class="animated fadeOutRight">
    <div class="alert alert-success notification-bar" v-if="successMSG" @click="successMSG = false">{{successMSG}}</div>
</transition>
<transition enter-active-class="animated fadeInLeft" leave-active-class="animated fadeOutRight">
    <div class="alert alert-danger notification-bar" v-if="errorMSG" @click="errorMSG = false">{{errorMSG}}</div>
</transition>
    <main>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-5">
                    <div class="login-form">
                        <p class="text-center form-heading">Login</p>
                            <div class="mb-5">
                                <label for="email">Email:</label>
                                <input type="email" class="form-control" id="email" name="email" v-model="newUser.email">
                                <div class="text-danger" v-html="formValidate.email"></div>
                            </div>

                            <div class="mb-5">
                                <label for="pass">Password:</label>
                                <input type="password" class="form-control" id="pass" name="pass" v-model="newUser.pass">
                                <div class="text-danger" v-html="formValidate.pass"></div>
                            </div>
                            
                            <div class="custom-control custom-checkbox mb-5">
                                <input id="remember_me" name="remember_me" v-model="newUser.pass" type="checkbox" class="custom-control-input">
                                <label for="remember_me" class="custom-control-label">Remember me</label>
                            </div>
                            
                            <div class="mb-5">
                                <button class="btn btn-primary" type="submit" v-on:click="submitForm">Login</button>
                            </div>
                        <div class="link_wrapper clearfix">
                            <a href="#" class="float-left">Forgot password?</a>
                            <a href="<?php echo site_url('register');?>" class="float-right">Create new account</a>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </main>
</div>
<script>
var app=new Vue({
    el: '#app',
    data: {
        url:'<?php echo site_url('login/submitForm');?>',
        newUser:{
            email:'',
            pass:'',
            remember_me:''
        },
        successMSG:'',
        errorMSG:'',
        formValidate:[],
    },
    methods: {
        formData(obj){
            var formDetail = new FormData();
		    for ( var key in obj ) {
		        formDetail.append(key, obj[key]);
            }
		    return formDetail;
        },
        submitForm(){      
            app.errorMSG='';
            var formData = app.formData(app.newUser);
            axios.post(this.url, formData).then(function(response){
                if(response.data.error){
                    if(response.data.form){
                        app.errorMSG = response.data.form;
                        setTimeout(function(){
                            app.errorMSG='';
                        },5000);
                    }else{
                        app.formValidate = response.data.msg;
                    }
                }else{
                    app.successMSG = response.data.msg;
                    app.clearFormData();
                    app.clearMSG(response.data.path);
                }
            })
        },
        clearFormData(){
            app.newUser={
                email:'',
                pass:'',
                remember_me:''
            };
            app.formValidate = false;
        },
        clearMSG(path){
            setTimeout(function(){
                app.successMSG='';
                window.location.href=path;
			},2000); // disappearing message success in 2 sec
        },
    }
});
</script>
</body>
</html>