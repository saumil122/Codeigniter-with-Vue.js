
<cart-view v-if="cartBool" :cart="cart" :cart-sub-total="cartSubTotal" :tax="tax" :shipping-charge="shippingCharge" :cart-total="cartTotal"></cart-view>

<checkout-view v-if="checkoutBool" :cart="cart" :cart-sub-total="cartSubTotal" :tax="tax" :shipping-charge="shippingCharge" :cart-total="cartTotal"></checkout-view>

<categories-view v-for="category in categories" :category="category" :cart="cart"></categories-view>