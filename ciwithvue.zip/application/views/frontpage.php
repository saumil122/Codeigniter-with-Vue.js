<!DOCTYPE html>
<html lang=en>
<head>
    <meta charset=utf-8>
    <meta http-equiv=X-UA-Compatible content="IE=edge">
    <meta name=viewport content="width=device-width,initial-scale=1,shrink-to-fit=no">
    <meta name=description content="Start your development with a Design System for Bootstrap 4 and Vue.js">
    <meta name=author content="Saumil Nagariya">
    <title><?php echo $title ?> - Codeigniter with Vue.js</title>
    <link href="<?php echo site_url('/assets/css/bootstrap.css')?>" rel="stylesheet">
    <link href="<?php echo site_url('/assets/css/open-iconic-bootstrap.css')?>" rel="stylesheet">
    <link href="<?php echo site_url('/assets/css/main.css')?>" rel="stylesheet">
    
    <script src="<?php echo site_url('/assets/js/jquery-3.4.1.js')?>"></script>
    <script src="<?php echo site_url('/assets/js/popper.js')?>"></script>
    <script src="<?php echo site_url('/assets/js/bootstrap.js')?>"></script>
    <script src="<?php echo site_url('/assets/js/vue.js')?>"></script>
    <script src="<?php echo site_url('/assets/js/vue-router.js')?>"></script>
    <script src="<?php echo site_url('/assets/js/axios.min.js')?>"></script>
<head>
<body>

<!-- component template -->
<script type="text/x-template" id="checkout-template">
  <div class="order_summery_wrapper">
    <div class="container">
      <div class="row">
        <div class="col-12">  
          <div class="cart_items">
            <h2 class="order_summery_heading">Order summery</h2>
            <p>Shipping and additional costs are calculated based on values you have entered.</p>
            <table class="table">
              <thead class="thead-light">
                <tr>
                  <th>&nbsp;</th>
                  <th>Product</th>
                  <th>Quantity</th>
                  <th>Price</th>
                </tr>
              </thead> 
              <tbody>
                <tr v-for="product in cart">
                  <td><img :src="product.image" alt="" class="cart-image"/></td>
                  <td>{{product.name}}</td>
                  <td>{{product.quantity}}</td>
                  <td>{{product.price}}</td>
                </tr>
                <tr>
                  <th colspan="3" class="text-right">Subtotal:</th>
                  <td>{{cartSubTotal | numberFormate}}</td>
                </tr>
                <tr>
                  <th colspan="3" class="text-right">Tax:</th>
                  <td>{{tax | numberFormate}}</td>
                </tr>
                <tr>
                  <th colspan="3" class="text-right">Shipping charges:</th>
                  <td>{{shippingCharge | numberFormate}}</td>
                </tr>
                <tr>
                  <th colspan="3" class="text-right">Total:</th>
                  <td>{{cartTotal | numberFormate}}</td>
                </tr>
              </tbody>
            </table>
          </div>
          <p>Cuurently we are accepting orders through Cash on delivery.</p>
          <div class="cart_buttons row">
            <div class="col-12">
              <button class="btn btn-success" @click="placeOrder()">Place order</button>
            </div>
          </div>
        </div>
      </div>
    </div>
	</div>
</script>

<!-- component template -->
<script type="text/x-template" id="cart-template">
  <div class="cart_wrapper">
    <div class="container">
      <div class="row">
        <div class="col-12">  
          <div class="cart_items">
            <h2 class="cart_heading">Cart</h2>
            <table class="table">
              <thead class="thead-light">
                <tr>
                  <th>&nbsp;</th>
                  <th>&nbsp;</th>
                  <th>Product</th>
                  <th>Quantity</th>
                  <th>Price</th>
                </tr>
              </thead> 
              <tbody>
                <tr v-for="product in cart">
                  <td><button class="btn btn-danger btn-sm"  @click="removeProduct(product)"><span class="oi oi-trash"></span></button></td>
                  <td><img :src="product.image" alt="" class="cart-image"/></td>
                  <td>{{product.name}}</td>
                  <td>{{product.quantity}}</td>
                  <td>{{product.price}}</td>
                </tr>
                <tr>
                  <th colspan="4" class="text-right">Subtotal:</th>
                  <td>{{cartSubTotal | numberFormate}}</td>
                </tr>
                <tr>
                  <th colspan="4" class="text-right">Tax:</th>
                  <td>{{tax | numberFormate}}</td>
                </tr>
                <tr>
                  <th colspan="4" class="text-right">Shipping charges:</th>
                  <td>{{shippingCharge | numberFormate}}</td>
                </tr>
                <tr>
                  <th colspan="4" class="text-right">Total:</th>
                  <td>{{cartTotal | numberFormate}}</td>
                </tr>
              </tbody>
            </table>
          </div>
          <div class="cart_buttons row">
            <div class="col-6 text-left">
              <button class="btn btn-dark" @click="clearCart()">Clear cart</button>
            </div>
            <div class="col-6 text-right">
              <button class="btn btn-success" :disabled='isDisabled' @click="proceedToCheckout()">Checkout</button>
            </div>
          </div>
        </div>
      </div>
    </div>
	</div>
</script>

<!-- component template -->
<script type="text/x-template" id="product-template">
	<div class="col-4 product-item">
		<div class="product-card">
			<div class="product_image">
				<img :src="product.image" alt=""/>
			</div>
			<div class="product_title">{{ product.name }}</div>
			<div class="product_price"><?php echo CURRENCY_SYM;?> {{ product.price }}</div>
			<div class="product_extra"><button class="btn btn-primary" @click="addToCart(product)">Add to Cart</button></div>
		</div>
	</div>
</script>

<!-- component template -->
<script type="text/x-template" id="category-template">
	<section class="products_wrapper" v-bind:id="'product_section_' + category.category_id">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<h2 class="category_title">{{ category.category_name }}</h2>
				</div>
				<product-view v-for="product in category.products" :product="product" :cart="cart"> </product-view>
			</div>
		</div>
	</section>
</script>
<div id="app">
  <transition enter-active-class="animated fadeInLeft" leave-active-class="animated fadeOutRight">
      <div class="alert alert-success notification-bar" v-if="successMSG" @click="successMSG = false">{{successMSG}}</div>
  </transition>
  <transition enter-active-class="animated fadeInLeft" leave-active-class="animated fadeOutRight">
      <div class="alert alert-danger notification-bar" v-if="errorMSG" @click="errorMSG = false">{{errorMSG}}</div>
  </transition>
    <main class="main_wrapper">
    <header class="header header-dark header-sticky">
      <div class="container">
        <div class="row">
            <div class="col-3">
                <a href="<?php echo site_url();?>" class="navbar-brand">STORE</a>
            </div>
            <div class="col-9">
          <nav class="navbar navbar-expand-md navbar-dark">
            
            <div class="collapse navbar-collapse" id="navbarMenu1">
              <ul class="navbar-nav ml-auto">
                <?php if ($this->session->userdata('isUserLoggedIn')){ ?>
                  <?php if ($this->session->userdata('level') == '1') {?>
                    <li class="nav-item">
                      <a class="nav-link" href="<?php echo site_url('admin/dashboard')?>">Dashboard</a>
                    </li>
                  <?php }?>
                <li class="nav-item">
                  <a class="nav-link" href="<?php echo site_url('login/logout')?>">Log out</a>
                </li>
                <?php }else{ ?>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo site_url('login')?>">Log In</a>
                  </li>
                <?php } ?>
                
                <li class="nav-item">
                  <a href="#" class="nav-link"><span class="oi oi-magnifying-glass"></span></a>
                </li>
                <li id="cart_button" class="nav-item cart">
                  <a @click="showCartView()" class="nav-link"><span>Cart</span><span>{{cartCount}}</span></a>
                </li>
              </ul>
            </div>
          </nav>
            </div>
        </div>
      </div>
    </header>    
    
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img class="d-block w-100" src="<?php echo site_url('assets/images/slider-image-1.png')?>" alt="First slide" />
            </div>
            <div class="carousel-item">
                <img class="d-block w-100" src="<?php echo site_url('assets/images/slider-image-2.png')?>" alt="Second slide" />
            </div>
            <div class="carousel-item">
                <img class="d-block w-100" src="<?php echo site_url('assets/images/slider-image-3.png')?>" alt="Third slide" />
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>

        <div class="main_content">
            <?php echo $contents ?>
        </div>
        <footer>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 copyright text-center">
                            <p>&copy; <?php echo date('Y');?>, developed by <a href="https://github.com/saumil122">Saumil Nagariya</a></p> 
                    </div>
                </div>
            </div>
        </footer>
    </main>
</div>

<script>

Vue.component("product-view", {
	template:'#product-template',
	props:{
		product: Object,
        cart: Object,
	},
	methods:{
		addToCart: function(product) {
			var found = false;
			for (var i = 0; i < app.cart.length; i++) {
        //console.log(app.cart[i]);
				if (app.cart[i].product_id === product.product_id) {
					var newProduct = app.cart[i];
					newProduct.quantity = newProduct.quantity + 1;
					//console.log("DUPLICATE",  app.cart[i].product_id + "'s quantity is now: " + app.cart[i].quantity);
					found = true;
					break;
				}
			}

			if(!found) {
				product.quantity = 1;
				app.cart.push(product);
        app.cartCount=app.cart.length;
			}

			app.cartSubTotal = parseFloat(app.cartSubTotal) + parseFloat(product.price);
			app.cartTotal = app.cartSubTotal + (app.tax * app.cartSubTotal) + app.shippingCharge;
			
		},
	}
});

Vue.component("categories-view", {
	template:'#category-template',
	props:{
		category: Object,
        cart:Object,
	},
	
});

Vue.component("cart-view", {
	template:'#cart-template',
  props: ['cart', 'cartSize', 'cartSubTotal', 'tax', 'shippingCharge', 'cartTotal'],
	data: function() {
        return {
          cartBool: false
        }
    },
  computed: {
  	isDisabled: function(){
    	return (app.cart.length > 0)? false : true;
    }
  },
    filters: {
        cartSize(cart) {
            var cartSize = 0;

            for (var i = 0; i < cart.length; i++) {
                cartSize += cart[i].quantity;
            }

            return cartSize;
        },
        numberFormate(val){
            return parseFloat(val).toFixed(2);;
        }
    },
    methods: {
      removeProduct: function(product){
        app.cart.splice(app.cart.indexOf(product), 1);  
        app.cartSubTotal = parseFloat(app.cartSubTotal) - (parseFloat(product.price) * parseInt(product.quantity));
        app.cartTotal = app.cartSubTotal + (app.tax * app.cartSubTotal) + app.shippingCharge;
        app.cartCount=app.cart.length;

        if(app.cart.length <= 0) {
          app.cartBool = false;
        }
      },
      clearCart: function(){
        app.cart = [];
        app.cartSubTotal = 0;
        app.cartTotal = 0;
        app.cartCount=0;
        app.checkoutBool = false;
        app.cartBool = false;
      },
      proceedToCheckout: function(){
        app.checkoutBool = true;
        app.cartBool = false;
      }
    }
});

Vue.component("checkout-view", {
	template:'#checkout-template',
  props: ['cart', 'cartSubTotal', 'tax', 'shippingCharge', 'cartTotal'],
  filters: {
    numberFormate(val){
      return parseFloat(val).toFixed(2);;
    }
  },
  methods: {
    placeOrder(){
      var formData = app.formData();
      axios.post("<?php echo site_url('store/generateOrder');?>", formData).then(function(response){
          if(response.data.error){
            app.errorMSG = response.data.msg;
          }else{
            app.successMSG = response.data.msg;
            app.cart = [];
            app.cartSubTotal = 0;
            app.cartTotal = 0;
            app.cartCount=0;
            app.checkoutBool = false;
            app.cartBool = false;
          }
          app.clearMSG();
      })
    }
  }
});

var app = new Vue({
    el:'#app',
	data:{
		categories:{},
		cart: [],
		cartSubTotal: 0,
		tax: <?php echo TAX; ?>,
		shippingCharge: <?php echo SHIPPING_CHARGE; ?>,
		cartTotal: 0,
    cartCount:0,
    showProducts:true,
    checkoutBool: false,
    cartBool:false,
    errorMSG:'',
    successMSG:'',
	},
	created(){
    this.getRecords(); 
    this.showProductView();
  },
	methods:{
		getRecords(){
        axios.get("<?php echo site_url('store/getProductByCategories');?>").then(function(response){
                  if(response.data.categories == null || response.data.categories===false){
                      //nothing to do.
                  }else{
                      app.categories=response.data.categories;
                  }
              })
		},
    showProductView(){
      this.showProducts=true;
      this.cartBool=false;
    },
    showCartView(){
      this.showProducts=false;
      this.cartBool=true;
    },
    formData(){
      var obj=app.cart;
			var formData = new FormData();
      formData.append('cartSubTotal', app.cartSubTotal);
      formData.append('cartTotal', app.cartTotal);
      formData.append('cartCount', app.cartCount);
		   
      //get all produc ids from cart data
      var product_ids = new Array();
      var product_qty = new Array();
      for ( var key in obj ) {
          
          for ( var key1 in obj[key] ) {
              if(key1=='product_id'){
                  product_ids.push(obj[key][key1]);
              }
          }
          
          for ( var key1 in obj[key] ) {
              if(key1=='quantity'){
                  product_qty.push(obj[key][key1]);
              }
          }
		  } 
      //console.log(product_ids); 
      //console.log(product_qty);
      formData.append('product_ids', product_ids);
      formData.append('product_qty', product_qty);

		  return formData;
		},
    clearMSG(){
      setTimeout(function(){
                app.successMSG='';
                app.errorMSG='';
			},5000); // disappearing message success in 5 sec
    },
	}
});
</script>
</body>
</html>