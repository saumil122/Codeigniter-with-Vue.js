<div class="content_holder">
    <div class="container-fuild">
        <div class="row">
            <div class="col-12">
            <transition enter-active-class="animated fadeInLeft" leave-active-class="animated fadeOutRight">
                <div class="alert alert-success notification-bar" v-if="successMSG" @click="successMSG = false">{{successMSG}}</div>
            </transition>
            <transition enter-active-class="animated fadeInLeft" leave-active-class="animated fadeOutRight">
                <div class="alert alert-danger notification-bar" v-if="errorMSG" @click="errorMSG = false">{{errorMSG}}</div>
            </transition>
                <div class="top-panel mb-3">
                    <div class="row">
                        <div class="col"><button class="btn btn-primary btn-sm" @click="addModal= true">Add</button></div>
                        <div class="col"><input placeholder="Search"type="search" class="form-control" v-model="search.text" @keyup="searchRecord" name="search"></div>
                    </div>
                </div>
                <div class="record-list">
                    <div class="table-responsive">    
                        <table class="table">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Fullname</th>
                                    <th scope="col">Address</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">mobile</th>
                                    <th scope="col">Level</th>
                                    <th colspan="2" class="text-right" scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="r in records" class="table-default">
                                    <td>{{r.user_id}}</td>
                                    <td>{{r.fullname}}</td>
                                    <td>{{r.address}}</td>
                                    <td>{{r.email}}</td>
                                    <td>{{r.mobile}}</td>
                                    <td>{{r.level}}</td>
                                    <td><button class="btn btn-primary btn-sm" @click="editModal = true; selectRecord(r)"><span class="oi oi-pencil"></span></button></td>
                                    <td><button class="btn btn-danger btn-sm" @click="deleteModal = true; selectRecord(r)"><span class="oi oi-trash"></span</button></td>
                                </tr>
                                <tr v-if="emptyResult">
                                    <td colspan="8">No Record Found</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <pagination :current_page="currentPage" :row_count_page="rowCountPage" @page-update="pageUpdate" :total_records="totalRecords" :page_range="pageRange"></pagination>
            </div>
        </div>
    </div>
</div>


<!--add modal-->
<modal v-if="addModal" @close="clearAll()">
    <h3 slot="head" >Add record</h3>
    <div slot="body" class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label>Fullname</label>
                <input type="text" class="form-control" :class="{'is-invalid': formValidate.fullname}" name="fullname" v-model="newRecord.fullname">
                <div class="text-danger" v-html="formValidate.fullname"></div>
            </div>
            <div class="form-group">
                <label>Address</label>
                <textarea class="form-control" :class="{'is-invalid': formValidate.address}" name="address" rows="3" v-model="newRecord.address"></textarea>
                <div class="text-danger" v-html="formValidate.address"></div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label>Email</label>
                <input type="text" class="form-control" :class="{'is-invalid': formValidate.email}" name="email" v-model="newRecord.email">
                <div class="text-danger" v-html="formValidate.email"></div>
            </div>    
            <div class="form-group">
                <label>Password</label>
                <input type="password" class="form-control" :class="{'is-invalid': formValidate.pass}" name="pass" v-model="newRecord.pass">
                <div class="text-danger" v-html="formValidate.pass"></div>
            </div> 
            <div class="form-group">
                <label>Mobile</label>
                <input type="text" class="form-control" :class="{'is-invalid': formValidate.mobile}" name="mobile" v-model="newRecord.mobile">
                <div class="text-danger" v-html="formValidate.mobile"></div>
            </div> 
        </div>
    </div>
    <div slot="foot"><button class="btn btn-primary" @click="addRecord">Submit</button></div>
</modal>


<!--update modal-->
<modal v-if="editModal" @close="clearAll()">
    <h3 slot="head" >Edit record</h3>
    <div slot="body" class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label>Fullname</label>
                <input type="text" class="form-control" :class="{'is-invalid': formValidate.fullname}" name="fullname" v-model="chooseRecord.fullname">
                <div class="text-danger" v-html="formValidate.fullname"></div>
            </div>
            <div class="form-group">
                <label>Address</label>
                <textarea class="form-control" :class="{'is-invalid': formValidate.address}" name="address" rows="3" v-model="chooseRecord.address"></textarea>
                <div class="text-danger" v-html="formValidate.address"></div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label>Email</label>
                <input type="text" class="form-control" :class="{'is-invalid': formValidate.email}" name="email" v-model="chooseRecord.email">
                <div class="text-danger" v-html="formValidate.email"></div>
            </div>    
            <div class="form-group">
                <label>Password</label>
                <input type="password" class="form-control" :class="{'is-invalid': formValidate.pass}" name="pass" v-model="chooseRecord.pass">
                <div class="text-danger" v-html="formValidate.pass"></div>
            </div> 
            <div class="form-group">
                <label>Mobile</label>
                <input type="text" class="form-control" :class="{'is-invalid': formValidate.mobile}" name="mobile" v-model="chooseRecord.mobile">
                <div class="text-danger" v-html="formValidate.mobile"></div>
            </div> 
        </div>
    </div>
    <div slot="foot"><button class="btn btn-primary" @click="updateRecord">Submit</button></div>
</modal>


<!--delete modal-->
<modal v-if="deleteModal" @close="clearAll()">
    <h3 slot="head">Delete record</h3>
    <div slot="body">Do you want to delete this record?</div>
    <div slot="foot">
        <button class="btn btn-danger" @click="deleteModal = false; deleteRecord()">Delete</button>
        <button class="btn btn-secondary" @click="deleteModal = false">Cancel</button>
    </div>
</modal>


<script>
Vue.component('modal',{ //modal
    template:`
    <transition enter-active-class="animated rollIn" leave-active-class="animated rollOut">   
        <div class="modal is-active" >
            <div class="modal-background"></div>
            <div class="modal-card border border border-secondary">
                <div class="modal-card-head text-center bg-dark">
                    <div class="modal-card-title text-white">
                        <slot name="head"></slot>
                    </div>
                    <button class="delete" @click="$emit('close')"></button>
                </div>
                <div class="modal-card-body">
                    <slot name="body"></slot>
                </div>
                <div class="modal-card-foot" >
                    <slot name="foot"></slot>
                </div>
            </div>
        </div>
    </transition>`
});

var app = new Vue({
    el:'#app',
    data:{
        addModal: false,
        editModal:false,
        deleteModal:false,
        records:[],
        search: {
            text: ''
        },
        emptyResult:false,
        newRecord:{
            user_id:'',
            fullname:'',
            address:'',
            email:'',
            pass:'',
            mobile:'',
            level:''
        },
        chooseRecord:{},
        formValidate:[],
        successMSG:'',
        errorMSG:'',
        
        //pagination
        currentPage: 0,
        rowCountPage:5,
        totalRecords:0,
        pageRange:2
    },
    created(){
        this.showAll(); 
    },
    methods:{
        showAll(){ 
            axios.get("<?php echo site_url('user/getAllRecords');?>").then(function(response){
                if(response.data.records == null || response.data.records===false){
                    app.noResult()
                }else{
                    app.getData(response.data.records);
                }
            })
        },
        searchRecord(){
            var formData = app.formData(app.search);
            axios.post("<?php echo site_url('user/searchRecord');?>", formData).then(function(response){
                if(response.data.records == null || response.data.records===false){
                    app.noResult()
                }else{
                      app.getData(response.data.records);                    
                } 
            })
        },
        addRecord(){   
            var formData = app.formData(app.newRecord);
            axios.post("<?php echo site_url('user/addRecord');?>", formData).then(function(response){
                if(response.data.error){
                    if(response.data.form){
                        app.errorMSG = response.data.form;
                        app.clearAll();
                        app.clearMSG();
                    }else{
                        app.formValidate = response.data.msg;
                    }
                }else{
                    app.successMSG = response.data.msg;
                    app.clearAll();
                    app.clearMSG();
                }
            })
        },
        updateRecord(){
            var formData = app.formData(app.chooseRecord); 
            axios.post('"<?php echo site_url('user/updateRecord');?>"', formData).then(function(response){
                if(response.data.error){
                    if(response.data.form){
                        app.errorMSG = response.data.form;
                        app.clearAll();
                        app.clearMSG();
                    }else{
                        app.formValidate = response.data.msg;
                    }
                }else{
                    app.successMSG = response.data.msg;
                    app.clearAll();
                    app.clearMSG();
                }
            })
        },
        deleteRecord(){
            var formData = app.formData(app.chooseRecord);
            axios.post('"<?php echo site_url('user/deleteRecord');?>"', formData).then(function(response){
                if(response.data.error){
                    app.errorMSG = response.data.form;
                }else{
                    app.successMSG = response.data.msg;
                }
                app.clearAll();
                app.clearMSG();
            })
        },
        formData(obj){
			var formData = new FormData();
		    for ( var key in obj ) {
		        formData.append(key, obj[key]);
		    } 
		    return formData;
		},
        getData(records){
            app.emptyResult = false; // become false if has a record
            app.totalRecords = records.length //get total of records
            app.records = records.slice(app.currentPage * app.rowCountPage, (app.currentPage * app.rowCountPage) + app.rowCountPage); //slice the result for pagination
            
             // if the record is empty, go back a page
            if(app.records.length == 0 && app.currentPage > 0){ 
                app.pageUpdate(app.currentPage - 1)
                app.clearAll();  
            }
        },  
        selectRecord(record){
            app.chooseRecord = record; 
        },
        clearMSG(){
            setTimeout(function(){
                app.successMSG='';
                app.errorMSG='';
			},5000); // disappearing message success in 5 sec
        },
        clearAll(){
            app.newRecord = { 
                user_id:'',
                fullname:'',
                address:'',
                email:'',
                pass:'',
                mobile:'',
                level:''
            };
            app.formValidate = false;
            app.addModal= false;
            app.editModal=false;
            app.deleteModal=false;
            app.refresh()
        },
        noResult(){
            app.emptyResult = true;  // become true if the record is empty, print 'No Record Found'
            app.records = null 
            app.totalRecords = 0 //remove current page if is empty  
        },
        pageUpdate(pageNumber){
            app.currentPage = pageNumber; //receive currentPage number came from pagination template
            app.refresh()  
        },
        refresh(){
            app.search.text ? app.searchRecord() : app.showAll(); //for preventing
        }
    }
})
</script>