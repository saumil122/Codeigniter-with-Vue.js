<!DOCTYPE html>
<html lang=en>
<head>
    <meta charset=utf-8>
    <meta http-equiv=X-UA-Compatible content="IE=edge">
    <meta name=viewport content="width=device-width,initial-scale=1,shrink-to-fit=no">
    <meta name=description content="Start your development with a Design System for Bootstrap 4 and Vue.js">
    <meta name=author content="Saumil Nagariya">
    <title><?php echo $title ?> - Codeigniter with Vue.js</title>
    <link href="<?php echo site_url('/assets/css/bootstrap.css')?>" rel="stylesheet">
    <link href="<?php echo site_url('/assets/css/bulma.min.css')?>" rel="stylesheet">
    <link href="<?php echo site_url('/assets/css/open-iconic-bootstrap.css')?>" rel="stylesheet">
    <link href="<?php echo site_url('/assets/css/main.css')?>" rel="stylesheet">
    <link href="<?php echo site_url('/assets/css/admin.css')?>" rel="stylesheet">
    
    <script src="<?php echo site_url('/assets/js/jquery-3.4.1.js')?>"></script>
    <script src="<?php echo site_url('/assets/js/popper.js')?>"></script>
    <script src="<?php echo site_url('/assets/js/bootstrap.js')?>"></script>
    <script src="<?php echo site_url('/assets/js/vue.js')?>"></script>
    <script src="<?php echo site_url('/assets/js/vue-router.js')?>"></script>
    <script src="<?php echo site_url('/assets/js/axios.min.js')?>"></script>
<head>
<body>
<div id="app">
    <main class="main_wrapper">
        <div class="sidebar-wrapper">
            <div class="sidebar">
                <ul class="nav">
                    <li class="nav-item <?php echo ($title=='Dashboard')?'active':'';?>">
                        <a href="<?php echo site_url('admin/dashboard');?>" class="nav-link">
                            <span class="oi oi-home"></span>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-item <?php echo ($title=='Category')?'active':'';?>">
                        <a href="<?php echo site_url('admin/category');?>" class="nav-link">
                            <span class="oi oi-list-rich"></span>
                            <span>Category</span>
                        </a>
                    </li>
                    <li class="nav-item <?php echo ($title=='Product')?'active':'';?>">
                        <a href="<?php echo site_url('admin/product');?>" class="nav-link">
                            <span class="oi oi-image"></span>
                            <span>Product</span>
                        </a>
                    </li>
                    <li class="nav-item <?php echo ($title=='Orders')?'active':'';?>">
                        <a href="<?php echo site_url('admin/orders');?>" class="nav-link">
                            <span class="oi oi-clipboard"></span>
                            <span>Orders</span>
                        </a>
                    </li>
                    <li class="nav-item <?php echo ($title=='Users')?'active':'';?>">
                        <a href="<?php echo site_url('admin/users');?>" class="nav-link">
                            <span class="oi oi-people"></span>
                            <span>Users</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="main_panel">
            <nav class="navbar navbar-expand-md navbar-absolute navbar-transparent">
                <div class="navbar-wrapper">
                    <div class="navbar-toggle">
                        <button type="button" aria-label="Navbar toggle button" class="navbar-toggler">
                            <span class="oi oi-menu"></span>
                        </button>
                    </div>
                    <a href="#" class="navbar-brand"><?php echo $title;?></a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="navbar-nav ml-auto">
                        <li class="dropdown nav-item">
                            <a href="#" data-toggle="dropdown" aria-expanded="true" class="dropdown-toggle nav-link">
                                <span class="oi oi-person"></span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-right dropdown-navbar">
                                <li class="nav-link">
                                    <a href="#" class="nav-item dropdown-item">Profile</a>
                                </li>
                                <li class="nav-link">
                                    <a href="#" class="nav-item dropdown-item">Setting</a>
                                </li>
                                <div class="dropdown-divider"></div>
                                <li class="nav-link">
                                    <a href="<?php echo site_url('login/logout');?>" class="nav-item dropdown-item">Log out</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>
            <div class="main_content">
                <?php echo $contents ?>
            </div>
            <footer>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12 copyright text-right">
                                <p>&copy; <?php echo date('Y');?>, developed by <a href="https://github.com/saumil122">Saumil Nagariya</a></p> 
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </main>
</body>
</html>