<div class="content_holder">
    <div class="container-fuild">
        <div class="row">
            <div class="col-12">
                
            </div>
        </div>
    </div>
</div>