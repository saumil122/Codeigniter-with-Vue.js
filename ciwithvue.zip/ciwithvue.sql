-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 21, 2020 at 01:23 PM
-- Server version: 5.7.18
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ciwithvue`
--
CREATE DATABASE IF NOT EXISTS `ciwithvue` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `ciwithvue`;

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `cart_detail` text NOT NULL,
  `cart_total` float(11,2) NOT NULL,
  `created_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`) VALUES
(1, 'Games'),
(2, 'Movies'),
(3, 'Electronics');

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

DROP TABLE IF EXISTS `ci_sessions`;
CREATE TABLE `ci_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `data` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ci_sessions`
--

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES
('344cff68b6eedd64772337fe3a71922910202558', '::1', 1587458905, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373435383930353b),
('6062446e7b9b7a9c039efe172a5fc8006f3c7d1b', '::1', 1587459485, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373435393438353b),
('c461641accaeb80b7dd2bfabe35fd72051210925', '::1', 1587459791, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373435393739313b),
('809c4da91504dab783d968714caa9a43f510099a', '::1', 1587460270, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373436303237303b),
('a43bd8f56682ab56ff0bf19d60c82b37ce4eff93', '::1', 1587461227, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373436313232373b),
('6340a36b1cba09bba912f9d1d4163e0a1b183f52', '::1', 1587461832, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373436313833323b),
('16adce8edf96bd8261f33c6a369c02ab92f9e4ff', '::1', 1587462657, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373436323635373b),
('ed87fc9f3a2d27b86343c4d6096cdb59631d894c', '::1', 1587462995, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373436323939353b),
('07e10b9fd588f0df05ec1ab3f20c5313e63e1484', '::1', 1587463303, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373436333330333b),
('606d2a843e7878d1035cc9fdf6838968a7e60016', '::1', 1587463838, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373436333833383b),
('2a8019bf73c359b05648c8770cdf010b80c749fc', '::1', 1587464142, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373436343134323b),
('0e5dbd60526e8b20489ee29f2b14ddb3678ef35f', '::1', 1587464538, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373436343533383b),
('f95d0461daf3df22ee514dfc09d112bb9197caba', '::1', 1587465025, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373436353032353b),
('fabba9cfe36394156b939019660ed5228fb15a72', '::1', 1587465628, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373436353632383b),
('baa6e416d1d90444de6444d5bad57041d5efab87', '::1', 1587466021, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373436363032313b),
('c305b5c8b432eb6fcd1e9c37ebf0fa27899a54c4', '::1', 1587466328, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373436363332383b),
('6dd16b23bd94d6a4de4279986c4f145d0397dcb8', '::1', 1587467517, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373436373531373b),
('fb3e47823764cbe6ab08a9d59746261c3ee35479', '::1', 1587468269, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373436383236393b),
('59cde86120390d9a3f186c29fd74af17b574d152', '::1', 1587468269, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373436383236393b),
('b5e98b8192333f17b5888cc36b4bb47ffd383fb5', '::1', 1587469424, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373436393432343b),
('e554e36950c9f72df5647453ffe7ffabde79c6fa', '::1', 1587469959, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373436393935393b),
('61ff2c2f8a7c753876f79196acafd877b3e87fcc', '::1', 1587470428, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373437303432383b),
('f22e89ccae18167f8da0c0496dcaa6b1577767d1', '::1', 1587470854, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373437303835343b),
('7ea7623944cf81aa745c0e4569486b95d86a9101', '::1', 1587471174, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373437313137343b),
('74b77b21db05f70d8e23a8f543d6f5c94ca2affb', '::1', 1587471627, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373437313632373b),
('9032e6db6c7cc78dbd5ad1d9b35b475d2cb7b43e', '::1', 1587472254, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373437323235343b),
('b194e045f5684c7596158c75d3a8c4f0c26f7000', '::1', 1587472891, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373437323839313b),
('2eeba6464c92962fa5bc0c9ef7cb6577b1834758', '::1', 1587473274, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373437333237343b),
('167ffad470e0104de25d3fd4505b359d18767b83', '::1', 1587473618, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373437333631383b),
('f33d5776f9f56b32b38d02bf6cdfe0fed309ef69', '::1', 1587474140, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373437343134303b6973557365724c6f67676564496e7c623a313b7573657249647c733a313a2232223b66756c6c6e616d657c733a31353a225361756d696c204e61676172697961223b6c6576656c7c733a313a2232223b),
('c2e3bb230557a20f1fd9ae50985de98d186686a1', '::1', 1587474463, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373437343436333b6973557365724c6f67676564496e7c623a313b7573657249647c733a313a2232223b66756c6c6e616d657c733a31353a225361756d696c204e61676172697961223b6c6576656c7c733a313a2232223b),
('a3054ce0e421e7bc59dd6e349de53e27cd2adba3', '::1', 1587475070, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373437353037303b6973557365724c6f67676564496e7c623a313b7573657249647c733a313a2232223b66756c6c6e616d657c733a31353a225361756d696c204e61676172697961223b6c6576656c7c733a313a2232223b),
('ab2785dfcc2fcffb1e0bcb4d051c1f46a0c8ce54', '::1', 1587475244, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373437353130353b6973557365724c6f67676564496e7c623a313b7573657249647c733a313a2231223b66756c6c6e616d657c733a353a2261646d696e223b6c6576656c7c733a313a2231223b),
('242ffa29f9c459851b3fc8e5565ca5257622f054', '::1', 1587475269, 0x5f5f63695f6c6173745f726567656e65726174657c693a313538373437353235343b6973557365724c6f67676564496e7c623a313b7573657249647c733a313a2231223b66756c6c6e616d657c733a353a2261646d696e223b6c6576656c7c733a313a2231223b);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` enum('Pending','Shipped','Completed') DEFAULT 'Pending',
  `total` float(11,2) NOT NULL,
  `order_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `status`, `total`, `order_date`) VALUES
(1, 2, 'Pending', 1000.00, '2020-04-21 13:18:16');

-- --------------------------------------------------------

--
-- Table structure for table `order_product_map`
--

DROP TABLE IF EXISTS `order_product_map`;
CREATE TABLE `order_product_map` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_product_map`
--

INSERT INTO `order_product_map` (`id`, `order_id`, `product_id`, `quantity`) VALUES
(1, 1, 9, 1),
(2, 1, 8, 2),
(3, 2, 7, 3);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category` int(11) NOT NULL,
  `description` text NOT NULL,
  `image` text,
  `price` float(11,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `name`, `category`, `description`, `image`, `price`) VALUES
(1, 'Game: Product 1', 1, 'Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups.', 'http://localhost/ciwithvue/uploads/product-image-7.png', 100.00),
(2, 'Game: Product 2', 1, 'Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups.', 'http://localhost/ciwithvue/uploads/product-image-8.png', 200.00),
(3, 'Game: Product 3', 1, 'Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups.', 'http://localhost/ciwithvue/uploads/product-image-9.png', 300.00),
(4, 'Movie: Product 1', 2, 'Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups.', 'http://localhost/ciwithvue/uploads/product-image-4.png', 100.00),
(5, 'Movie: Product 2', 2, 'Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups.', 'http://localhost/ciwithvue/uploads/product-image-5.png', 200.00),
(6, 'Movie: Product 3', 2, 'Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups.', 'http://localhost/ciwithvue/uploads/product-image-6.png', 300.00),
(7, 'Electronics: Product 1', 3, 'Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups.', 'http://localhost/ciwithvue/uploads/product-image-1.png', 100.00),
(8, 'Electronic: Product 2', 3, 'Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups.', 'http://localhost/ciwithvue/uploads/product-image-2.png', 200.00),
(9, 'Electronic: Product 3', 3, 'Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups.', 'http://localhost/ciwithvue/uploads/product-image-3.png', 300.00);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `level` int(10) DEFAULT '2'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `fullname`, `address`, `email`, `mobile`, `pass`, `level`) VALUES
(1, 'admin', 'india', 'admin@admin.com', '1234567890', '21232f297a57a5a743894a0e4a801fc3', 1),
(2, 'Saumil Nagariya', 'India', 'saumil.nagariya@gmail.com', '7984591482', '25d55ad283aa400af464c76d713c07ad', 2),
(5, 'test', 'test', 'test@test.com', 'test', '098f6bcd4621d373cade4e832627b4f6', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `ci_sessions`
--
ALTER TABLE `ci_sessions`
  ADD KEY `ci_sessions_timestamp` (`timestamp`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `order_product_map`
--
ALTER TABLE `order_product_map`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `order_product_map`
--
ALTER TABLE `order_product_map`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
